Template created by Piranha305 
YouTube : https://www.youtube.com/user/armandoalonso305/videos
Twitter : https://twitter.com/piranha_305
Itch.io : https://piranha305.itch.io/
Github : https://github.com/armandoalonso

Original Assets used

https://0x72.itch.io/16x16-dungeon-tileset
https://superdark.itch.io/enchanted-forest-characters
https://ggbot.itch.io/quinquefive-font

